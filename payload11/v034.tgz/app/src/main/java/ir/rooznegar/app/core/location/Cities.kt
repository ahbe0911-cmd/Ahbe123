package ir.rooznegar.app.core.location

data class CityOption(
    val code: String,
    val title: String,
    val latitude: Double,
    val longitude: Double,
    val timezoneOffsetHours: Double
)

object IranianCities {
    val dozin = CityOption("dozin", "دوزین", 37.1261, 55.5791, 3.5)
    // Minudasht, Golestan. Used as the fixed prayer-time location.
    val minudasht = CityOption("minudasht", "مینودشت", 37.230147, 55.372111, 3.5)

    val all = listOf(
        dozin,
        minudasht,
        CityOption("tehran", "تهران", 35.6892, 51.3890, 3.5),
        CityOption("gorgan", "گرگان", 36.8427, 54.4439, 3.5),
        CityOption("mashhad", "مشهد", 36.2605, 59.6168, 3.5),
        CityOption("isfahan", "اصفهان", 32.6546, 51.6680, 3.5),
        CityOption("shiraz", "شیراز", 29.5918, 52.5837, 3.5),
        CityOption("tabriz", "تبریز", 38.0800, 46.2919, 3.5),
        CityOption("ahvaz", "اهواز", 31.3183, 48.6706, 3.5),
        CityOption("rasht", "رشت", 37.2808, 49.5832, 3.5)
    )

    fun byCode(code: String): CityOption = all.firstOrNull { it.code == code } ?: dozin
}
