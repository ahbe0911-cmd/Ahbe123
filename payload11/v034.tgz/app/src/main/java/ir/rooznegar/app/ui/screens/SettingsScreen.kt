package ir.rooznegar.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.rooznegar.app.core.location.IranianCities
import ir.rooznegar.app.data.ThemeMode
import ir.rooznegar.app.ui.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel, onRequestNotificationPermission: () -> Unit) {
    val settingsState by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(vm.exportBackup()) }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader -> runCatching { vm.importBackup(reader.readText()) } }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Spacer(Modifier.height(8.dp)); Text("تنظیمات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }

        item {
            SettingsCard("ظاهر") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(ThemeMode.SYSTEM to "سیستم", ThemeMode.LIGHT to "روشن", ThemeMode.DARK to "تاریک").forEach { (mode, label) ->
                        FilterChip(selected = settingsState.themeMode == mode, onClick = { vm.setTheme(mode) }, label = { Text(label) })
                    }
                }
            }
        }

        item {
            SettingsCard("هواشناسی من") {
                Text("انتخاب شهر برای هواشناسی؛ اوقات شرعی روی مینودشت، گلستان تنظیم است", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(IranianCities.all.size) { index ->
                        val city = IranianCities.all[index]
                        FilterChip(selected = settingsState.cityCode == city.code, onClick = { vm.setCity(city.code) }, label = { Text(city.title) })
                    }
                }
            }
        }

        item {
            SettingsCard("اعلان‌ها") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("نمایش تاریخ در نوار اعلان", Modifier.weight(1f))
                    Switch(settingsState.persistentDateNotification, vm::setDateBar)
                }
                Button(onClick = onRequestNotificationPermission, modifier = Modifier.fillMaxWidth()) { Text("اجازه اعلان‌ها") }
                if (Build.VERSION.SDK_INT >= 31) {
                    Button(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("اجازه یادآور دقیق") }
                }
            }
        }

        item {
            SettingsCard("نسخه پشتیبان") {
                Button(onClick = { export.launch("rooznegar-backup-v2.json") }, modifier = Modifier.fillMaxWidth()) { Text("خروجی Backup محلی") }
                Button(onClick = { import.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("بازیابی Backup") }
            }
        }

        item {
            Text(
                "نسخه ۰.۳.۴ • هواشناسی من با جزئیات زنده و اوقات شرعی ثابت مینودشت، گلستان.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        item { Spacer(Modifier.height(86.dp)) }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
