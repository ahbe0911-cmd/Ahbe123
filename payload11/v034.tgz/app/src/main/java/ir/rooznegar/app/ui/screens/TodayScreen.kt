package ir.rooznegar.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Air
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Opacity
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.Umbrella
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.rooznegar.app.core.calendar.JalaliCalendar
import ir.rooznegar.app.core.calendar.toPersianDigits
import ir.rooznegar.app.core.location.DailyForecast
import ir.rooznegar.app.core.location.HourlyForecast
import ir.rooznegar.app.core.location.IranianCities
import ir.rooznegar.app.core.location.PrayerTimesCalculator
import ir.rooznegar.app.core.location.WeatherSnapshot
import ir.rooznegar.app.data.TaskEntity
import ir.rooznegar.app.ui.AppViewModel
import ir.rooznegar.app.ui.WeatherUiState
import ir.rooznegar.app.ui.theme.RooznegarGreen
import ir.rooznegar.app.ui.theme.RooznegarOrange
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

@Composable
fun TodayScreen(
    vm: AppViewModel,
    onMenu: () -> Unit,
    onOpenHabits: () -> Unit,
    onOpenCountdowns: () -> Unit,
    onOpenPrayer: () -> Unit
) {
    var searchOpen by remember { mutableStateOf(false) }

    if (searchOpen) {
        SearchOverlayHost(vm = vm, onClose = { searchOpen = false })
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "header", contentType = "header") {
            TodayHeader(onMenu = onMenu, onSearch = { searchOpen = true })
        }
        item(key = "weather", contentType = "weather") { HomeWeatherSection(vm) }
        item(key = "prayer", contentType = "prayer") { PrayerSummarySection(vm, onOpenPrayer) }
        item(key = "tasks", contentType = "tasks") { TodayTasksSection(vm) }
        item(key = "notes", contentType = "notes") { PinnedNotesSection(vm) }
        item { Spacer(Modifier.height(92.dp)) }
    }
}

@Composable
private fun SearchOverlayHost(vm: AppViewModel, onClose: () -> Unit) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    SearchOverlay(tasks = tasks, notes = notes, onClose = onClose)
}

@Composable
private fun TodayHeader(onMenu: () -> Unit, onSearch: () -> Unit) {
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now(zone) }
    val jalali = remember(today) { JalaliCalendar.fromGregorian(today) }

    Column {
        Spacer(Modifier.height(5.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row {
                IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "منو") }
                IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "جستجو") }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("امروز", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "${JalaliCalendar.dayOfWeekFa(today)}، ${jalali.formatLong()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { }) { Icon(Icons.Outlined.Notifications, "اعلان‌ها") }
        }
    }
}

@Composable
private fun HomeWeatherSection(vm: AppViewModel) {
    val weatherState by vm.weather.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val city = remember(settings.cityCode) { IranianCities.byCode(settings.cityCode) }
    var detailsOpen by remember { mutableStateOf(false) }

    HomeWeatherCard(
        cityName = city.title,
        state = weatherState,
        onClick = { detailsOpen = true }
    )

    // Open immediately from cache, then refresh in the background while the live panel is visible.
    LaunchedEffect(detailsOpen, city.code) {
        if (detailsOpen) {
            vm.refreshWeather()
            while (true) {
                delay(5 * 60_000L)
                vm.refreshWeather()
            }
        }
    }

    if (detailsOpen) {
        WeatherDetailsDialog(
            cityName = city.title,
            state = weatherState,
            onRefresh = vm::refreshWeather,
            onDismiss = { detailsOpen = false }
        )
    }
}

@Composable
private fun HomeWeatherCard(cityName: String, state: WeatherUiState, onClick: () -> Unit) {
    val weather = state.snapshot
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("هواشناسی من", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (state.isRefreshing && weather == null) "در حال دریافت اطلاعات…" else "$cityName • برای جزئیات لمس کنید",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .72f)
                    )
                }
                if (state.isRefreshing && weather == null) {
                    CircularProgressIndicator(modifier = Modifier.size(26.dp), strokeWidth = 2.4.dp)
                } else {
                    Text(weather?.let { weatherEmoji(it.weatherCode, it.isDay) } ?: "🌦️", fontSize = 34.sp)
                }
            }

            if (weather == null) {
                Text(
                    if (state.hasError) "داده هوا دریافت نشد؛ پنل را باز کنید و دوباره تلاش کنید." else "—°",
                    style = if (state.hasError) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            } else {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(weather.label, style = MaterialTheme.typography.titleLarge)
                        Text(
                            "بیشینه ${p(weather.maxTemperatureC)}°  •  کمینه ${p(weather.minTemperatureC)}°",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .75f)
                        )
                    }
                    Text("${p(weather.temperatureC)}°", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WeatherHomeMetric(Modifier.weight(1f), "رطوبت", "${p(weather.humidityPercent)}٪")
                    WeatherHomeMetric(Modifier.weight(1f), "باد", "${p(weather.windSpeedKmh)} km/h")
                    WeatherHomeMetric(Modifier.weight(1f), "محسوس", "${p(weather.apparentTemperatureC)}°")
                }
                Text(
                    "پیش‌بینی ساعتی و ۷ روز آینده  ←",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun WeatherHomeMetric(modifier: Modifier, label: String, value: String) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .7f)
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PrayerSummarySection(vm: AppViewModel, onOpenPrayer: () -> Unit) {
    // Prayer location is intentionally independent from the weather city.
    val city = remember { IranianCities.minudasht }
    val now by produceState(initialValue = ZonedDateTime.now(ZoneId.of("Asia/Tehran"))) {
        while (true) {
            value = ZonedDateTime.now(ZoneId.of("Asia/Tehran"))
            delay(30_000L)
        }
    }
    val today = now.toLocalDate()
    val prayers = remember(today) { PrayerTimesCalculator.calculate(today, city) }
    val next = remember(today, prayers, now.hour, now.minute) {
        nextMainPrayer(today, city, prayers, now.toLocalTime())
    }

    Card(
        onClick = onOpenPrayer,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.DarkMode, null, tint = RooznegarGreen)
            Column(horizontalAlignment = Alignment.End) {
                Text(next.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${next.second} • اوقات شرعی مینودشت، گلستان", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun TodayTasksSection(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now(zone) }
    val start = remember(today) { today.atStartOfDay(zone).toInstant().toEpochMilli() }
    val end = remember(today) { today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() }
    val todayTasks by remember(tasks, start, end) {
        derivedStateOf {
            tasks.asSequence()
                .filter { !it.isCancelled && it.dueEpochMillis != null && it.dueEpochMillis in start until end }
                .sortedBy { it.dueEpochMillis }
                .take(4)
                .toList()
        }
    }
    val activeCount by remember(todayTasks) { derivedStateOf { todayTasks.count { !it.isCompleted } } }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("کارهای امروز", if (activeCount == 0) null else "${p(activeCount)} کار")
        if (todayTasks.isEmpty()) EmptyCard("برای امروز کاری ثبت نشده است.")
        else todayTasks.forEach { task -> CompactTask(task = task, onToggle = { vm.toggleTask(task) }) }
    }
}

@Composable
private fun TodayTimelineSection(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now(zone) }
    val start = remember(today) { today.atStartOfDay(zone).toInstant().toEpochMilli() }
    val end = remember(today) { today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() }
    val active by remember(tasks, start, end) {
        derivedStateOf {
            tasks.asSequence()
                .filter { !it.isCancelled && !it.isCompleted && it.dueEpochMillis != null && it.dueEpochMillis in start until end }
                .sortedBy { it.dueEpochMillis }
                .take(5)
                .toList()
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("برنامه امروز")
        if (active.isEmpty()) EmptyCard("برنامه امروز آزاد است؛ با + یک رویداد اضافه کن.")
        else active.forEach { task -> TimelineTask(task) }
    }
}

@Composable
private fun DailyToolsSection(
    vm: AppViewModel,
    onOpenHabits: () -> Unit,
    onOpenCountdowns: () -> Unit,
    onOpenPrayer: () -> Unit
) {
    val habits by vm.habits.collectAsStateWithLifecycle()
    val countdowns by vm.countdowns.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val today = remember { LocalDate.now() }
    val completedHabitsToday by remember(habits, today) {
        derivedStateOf {
            val day = today.toEpochDay()
            habits.count { h -> h.completedEpochDaysCsv.split(',').any { it.toLongOrNull() == day } }
        }
    }
    val city = remember(settings.cityCode) { IranianCities.byCode(settings.cityCode) }
    val prayers = remember(today, city.code) { PrayerTimesCalculator.calculate(today, city) }
    val nextPrayer = remember(prayers) { nextPrayer(prayers) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("ابزارهای روزانه")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            ToolCard(
                Modifier.weight(1f), "عادت‌ها", "${p(completedHabitsToday)}/${p(habits.size)}",
                Icons.Outlined.LocalFireDepartment, onOpenHabits
            )
            ToolCard(
                Modifier.weight(1f), "شمارش معکوس", p(countdowns.size),
                Icons.Outlined.Schedule, onOpenCountdowns
            )
            ToolCard(
                Modifier.weight(1f), "اوقات شرعی", nextPrayer.second,
                Icons.Outlined.DarkMode, onOpenPrayer
            )
        }
    }
}

@Composable
private fun PinnedNotesSection(vm: AppViewModel) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val pinned by remember(notes) { derivedStateOf { notes.filter { it.isPinned }.take(2) } }
    if (pinned.isEmpty()) return

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("یادداشت‌های مهم")
        pinned.forEach { note ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(15.dp)) {
                    Text(note.title.ifBlank { "یادداشت" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (note.body.isNotBlank()) {
                        Text(note.body, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun WeatherDetailsDialog(
    cityName: String,
    state: WeatherUiState,
    onRefresh: () -> Unit,
    onDismiss: () -> Unit
) {
    val weather = state.snapshot
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AnimatedVisibility(
            visible = entered,
            enter = fadeIn(tween(180)) + scaleIn(tween(220), initialScale = .92f),
            exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = .96f)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(.94f).fillMaxHeight(.88f),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item(key = "weather_dialog_header") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row {
                            IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "بستن") }
                            IconButton(onClick = onRefresh, enabled = !state.isRefreshing) {
                                if (state.isRefreshing) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Default.Refresh, "به‌روزرسانی")
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                LiveWeatherBadge(state.isRefreshing)
                                Text("هواشناسی من", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            }
                            Text("$cityName • اطلاعات زنده", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                if (weather == null) {
                    item {
                        Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("🌦️", fontSize = 42.sp)
                                Text("اطلاعات هوا در دسترس نیست", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("اتصال اینترنت را بررسی کنید و دکمه به‌روزرسانی را بزنید.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    item(key = "current") { CurrentWeatherHero(cityName, weather) }
                    item(key = "hourly_title") { SectionTitle("پیش‌بینی ساعتی", "۲۴ ساعت آینده") }
                    item(key = "hourly") { HourlyForecastRow(weather) }
                    item(key = "daily_title") { SectionTitle("۷ روز آینده") }
                    items(weather.daily, key = { it.epochDay }, contentType = { "weather_day" }) { day ->
                        DailyForecastRow(day)
                    }
                    item(key = "details_title") { SectionTitle("جزئیات هوا") }
                    item(key = "details") { WeatherMetricsGrid(weather) }
                    item(key = "sun") { SunTimesCard(weather) }
                    item(key = "source") {
                        Text(
                            "داده‌ها: Open‑Meteo • آخرین به‌روزرسانی ${weatherUpdatedTime(weather.updatedAt, weather.timezoneId)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun CurrentWeatherHero(cityName: String, weather: WeatherSnapshot) {
    val motion = rememberInfiniteTransition(label = "weather_motion")
    val floatY by motion.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(tween(1600), repeatMode = RepeatMode.Reverse),
        label = "weather_float"
    )

    Surface(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("اکنون در $cityName", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .72f))
                    Text(weather.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Text(
                    weatherEmoji(weather.weatherCode, weather.isDay),
                    modifier = Modifier.graphicsLayer { translationY = floatY },
                    fontSize = 48.sp
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Text(
                    "محسوس ${p(weather.apparentTemperatureC)}°\nبیشینه ${p(weather.maxTemperatureC)}° • کمینه ${p(weather.minTemperatureC)}°",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .78f)
                )
                AnimatedContent(
                    targetState = weather.temperatureC,
                    transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                    label = "temperature"
                ) { temperature ->
                    Text("${p(temperature)}°", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun LiveWeatherBadge(refreshing: Boolean) {
    val transition = rememberInfiniteTransition(label = "live_weather")
    val pulse by transition.animateFloat(
        initialValue = .38f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(850), repeatMode = RepeatMode.Reverse),
        label = "live_pulse"
    )
    Surface(shape = RoundedCornerShape(999.dp), color = RooznegarGreen.copy(alpha = .12f)) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(Modifier.size(7.dp).graphicsLayer { alpha = pulse }.background(RooznegarGreen, CircleShape))
            Text(if (refreshing) "در حال بروزرسانی" else "زنده", style = MaterialTheme.typography.labelSmall, color = RooznegarGreen, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HourlyForecastRow(weather: WeatherSnapshot) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(weather.hourly, key = { it.epochMillis }, contentType = { "weather_hour" }) { hour ->
            HourlyWeatherCard(hour, weather.timezoneId)
        }
    }
}

@Composable
private fun HourlyWeatherCard(hour: HourlyForecast, timezoneId: String) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier.width(82.dp).padding(vertical = 11.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(formatHour(hour.epochMillis, timezoneId), style = MaterialTheme.typography.labelMedium)
            Text(weatherEmoji(hour.weatherCode, true), fontSize = 25.sp)
            Text("${p(hour.temperatureC)}°", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (hour.precipitationProbabilityPercent > 0) {
                Text("${p(hour.precipitationProbabilityPercent)}٪ بارش", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            } else {
                Text(" ", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun DailyForecastRow(day: DailyForecast) {
    val date = remember(day.epochDay) { LocalDate.ofEpochDay(day.epochDay) }
    val jalali = remember(date) { JalaliCalendar.fromGregorian(date) }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${p(day.minTemperatureC)}°  /  ${p(day.maxTemperatureC)}°",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (day.precipitationProbabilityPercent > 0) {
                    Text("${p(day.precipitationProbabilityPercent)}٪", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(7.dp))
                }
                Text(weatherEmoji(day.weatherCode, true), fontSize = 24.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(JalaliCalendar.dayOfWeekFa(date), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("${p(jalali.day)} ${jalali.monthName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun WeatherMetricsGrid(weather: WeatherSnapshot) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WeatherMetric(Modifier.weight(1f), Icons.Outlined.Thermostat, "دمای محسوس", "${p(weather.apparentTemperatureC)}°")
            WeatherMetric(Modifier.weight(1f), Icons.Outlined.Opacity, "رطوبت", "${p(weather.humidityPercent)}٪")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WeatherMetric(Modifier.weight(1f), Icons.Outlined.Air, "سرعت باد", "${p(weather.windSpeedKmh)} km/h")
            WeatherMetric(Modifier.weight(1f), Icons.Outlined.Umbrella, "بارش فعلی", "${p(formatPrecipitation(weather.precipitationMm))} mm")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WeatherMetric(Modifier.weight(1f), Icons.Outlined.Cloud, "پوشش ابر", "${p(weather.cloudCoverPercent)}٪")
            WeatherMetric(Modifier.weight(1f), Icons.Outlined.Schedule, "به‌روزرسانی", weatherUpdatedTime(weather.updatedAt, weather.timezoneId))
        }
    }
}

@Composable
private fun SunTimesCard(weather: WeatherSnapshot) {
    val today = weather.daily.firstOrNull() ?: return
    val sunrise = today.sunriseEpochMillis?.let { formatClock(it, weather.timezoneId) } ?: "—"
    val sunset = today.sunsetEpochMillis?.let { formatClock(it, weather.timezoneId) } ?: "—"
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("طلوع و غروب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("غروب  $sunset", style = MaterialTheme.typography.bodyMedium)
                Text("طلوع  $sunrise", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun WeatherMetric(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Surface(modifier = modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(icon, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun CompactTask(task: TaskEntity, onToggle: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggle, modifier = Modifier.size(36.dp)) {
                Icon(
                    if (task.isCompleted) Icons.Outlined.CheckCircle else Icons.Outlined.Circle,
                    "تغییر وضعیت",
                    tint = if (task.isCompleted) RooznegarGreen else MaterialTheme.colorScheme.primary
                )
            }
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(kindLabel(task.kind), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            task.dueEpochMillis?.let { Text(formatTime(it), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Spacer(Modifier.size(8.dp))
            Box(Modifier.size(7.dp).background(priorityColor(task.priority), CircleShape))
        }
    }
}

@Composable
private fun TimelineTask(task: TaskEntity) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(task.dueEpochMillis?.let(::formatTime) ?: "—", modifier = Modifier.padding(end = 10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Box(Modifier.size(4.dp, 42.dp).background(priorityColor(task.priority), RoundedCornerShape(4.dp)))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                Text(task.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ToolCard(
    modifier: Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(modifier = modifier, onClick = onClick, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)) {
        Text(text, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun priorityColor(priority: Int): Color = when (priority) {
    1 -> RooznegarGreen
    3 -> Color(0xFFE86D72)
    else -> RooznegarOrange
}

private fun kindLabel(kind: String): String = when (kind) {
    "event" -> "رویداد"
    "reminder" -> "یادآور"
    "checklist" -> "چک‌لیست"
    else -> "کار"
}

private fun weatherEmoji(code: Int, isDay: Boolean): String = when (code) {
    0 -> if (isDay) "☀️" else "🌙"
    1, 2 -> if (isDay) "🌤️" else "☁️"
    3 -> "☁️"
    45, 48 -> "🌫️"
    in 51..67, in 80..82 -> "🌧️"
    in 71..77, in 85..86 -> "❄️"
    in 95..99 -> "⛈️"
    else -> "🌦️"
}

private fun formatTime(epoch: Long): String = Instant.ofEpochMilli(epoch)
    .atZone(ZoneId.systemDefault())
    .format(DateTimeFormatter.ofPattern("HH:mm"))
    .let(::toPersianDigits)

private fun formatHour(epoch: Long, timezoneId: String): String = Instant.ofEpochMilli(epoch)
    .atZone(zone(timezoneId))
    .format(DateTimeFormatter.ofPattern("HH:mm"))
    .let(::toPersianDigits)

private fun formatClock(epoch: Long, timezoneId: String): String = formatHour(epoch, timezoneId)

private fun weatherUpdatedTime(epoch: Long, timezoneId: String): String = formatHour(epoch, timezoneId)

private fun formatPrecipitation(value: Double): String = if (value == value.toInt().toDouble()) {
    value.toInt().toString()
} else {
    String.format(java.util.Locale.US, "%.1f", value)
}

private fun zone(timezoneId: String): ZoneId = runCatching { ZoneId.of(timezoneId) }.getOrElse { ZoneId.of("Asia/Tehran") }

private fun p(value: Int): String = toPersianDigits(value.toString())
private fun p(value: String): String = toPersianDigits(value)

private fun nextMainPrayer(
    date: LocalDate,
    city: ir.rooznegar.app.core.location.CityOption,
    prayers: ir.rooznegar.app.core.location.PrayerTimes,
    now: LocalTime
): Pair<String, String> {
    val todayEntries = listOf(
        "اذان صبح" to prayers.fajr,
        "طلوع آفتاب" to prayers.sunrise,
        "اذان ظهر" to prayers.dhuhr,
        "اذان مغرب" to prayers.maghrib
    )
    todayEntries.firstOrNull { (_, time) ->
        runCatching { now.isBefore(LocalTime.parse(time)) }.getOrDefault(false)
    }?.let { return it.first to toPersianDigits(it.second) }

    val tomorrowFajr = PrayerTimesCalculator.calculate(date.plusDays(1), city).fajr
    return "اذان صبح فردا" to toPersianDigits(tomorrowFajr)
}

private fun nextPrayer(p: ir.rooznegar.app.core.location.PrayerTimes): Pair<String, String> {
    val now = LocalTime.now()
    val entries = listOf("اذان صبح" to p.fajr, "طلوع آفتاب" to p.sunrise, "اذان ظهر" to p.dhuhr, "عصر" to p.asr, "اذان مغرب" to p.maghrib, "عشاء" to p.isha)
    val next = entries.firstOrNull { (_, time) -> runCatching { LocalTime.parse(time) }.getOrNull()?.isAfter(now) == true } ?: entries.first()
    return next.first to toPersianDigits(next.second)
}
