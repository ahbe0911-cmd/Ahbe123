package ir.rooznegar.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.rooznegar.app.core.calendar.JalaliCalendar
import ir.rooznegar.app.core.calendar.toPersianDigits
import ir.rooznegar.app.core.location.IranianCities
import ir.rooznegar.app.core.location.PrayerTimesCalculator
import ir.rooznegar.app.ui.AppViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun PrayerScreen(vm: AppViewModel, onMenu: () -> Unit) {
    val city = remember { IranianCities.minudasht }
    val now by produceState(initialValue = ZonedDateTime.now(ZoneId.of("Asia/Tehran"))) {
        while (true) {
            value = ZonedDateTime.now(ZoneId.of("Asia/Tehran"))
            delay(30_000L)
        }
    }
    val today = now.toLocalDate()
    val times = remember(today) { PrayerTimesCalculator.calculate(today, city) }
    val next = remember(today, times, now.hour, now.minute) { prayerNextLabel(today, city, times, now.toLocalTime()) }
    val qibla = remember { PrayerTimesCalculator.qiblaBearing(city).roundToInt() }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "منو") }
                Text("اوقات شرعی", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.size(48.dp))
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.LocationOn, null, tint = MaterialTheme.colorScheme.primary)
                        Text("مینودشت، گلستان", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Text("${next.first} بعدی", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                    Text(toPersianDigits(next.second), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(JalaliCalendar.fromGregorian(today).formatLong(JalaliCalendar.dayOfWeekFa(today)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item { PrayerTimeRow("اذان صبح", times.fajr) }
        item { PrayerTimeRow("طلوع آفتاب", times.sunrise) }
        item { PrayerTimeRow("اذان ظهر", times.dhuhr) }
        item { PrayerTimeRow("عصر", times.asr) }
        item { PrayerTimeRow("اذان مغرب", times.maghrib) }
        item { PrayerTimeRow("عشاء", times.isha) }
        item { PrayerTimeRow("نیمه‌شب شرعی", times.midnight) }

        item {
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Explore, null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text("جهت قبله از مینودشت، گلستان", fontWeight = FontWeight.Bold)
                        Text("زاویه از شمال جغرافیایی", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${toPersianDigits(qibla.toString())}°", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        item {
            Text(
                "اوقات شرعی برای شهرستان مینودشت، استان گلستان با محاسبات نجومی آفلاین و روش تهران محاسبه می‌شوند. برای کاربرد عبادی دقیق، با اعلام رسمی محل تطبیق دهید.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
        item { Spacer(Modifier.height(90.dp)) }
    }
}

@Composable
private fun PrayerTimeRow(label: String, value: String) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 11.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(toPersianDigits(value), fontWeight = FontWeight.Bold)
            Text(label)
        }
    }
}

private fun prayerNextLabel(
    date: LocalDate,
    city: ir.rooznegar.app.core.location.CityOption,
    p: ir.rooznegar.app.core.location.PrayerTimes,
    now: LocalTime
): Pair<String, String> {
    val entries = listOf(
        "اذان صبح" to p.fajr,
        "طلوع آفتاب" to p.sunrise,
        "اذان ظهر" to p.dhuhr,
        "اذان مغرب" to p.maghrib
    )
    entries.firstOrNull { (_, time) ->
        runCatching { now.isBefore(LocalTime.parse(time)) }.getOrDefault(false)
    }?.let { return it }
    val tomorrow = PrayerTimesCalculator.calculate(date.plusDays(1), city)
    return "اذان صبح فردا" to tomorrow.fajr
}
