package ir.rooznegar.app.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import ir.rooznegar.app.data.TaskEntity
import java.util.concurrent.TimeUnit

interface ReminderScheduler {
    fun schedule(task: TaskEntity)
    fun cancel(taskId: Long)
}

class AndroidReminderScheduler(private val context: Context) : ReminderScheduler {
    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    override fun schedule(task: TaskEntity) {
        val at = task.reminderEpochMillis ?: return
        if (at <= System.currentTimeMillis()) return
        val canExact = Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms()
        if (canExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(task.id))
        } else {
            val delay = (at - System.currentTimeMillis()).coerceAtLeast(0)
            val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(Data.Builder().putLong("taskId", task.id).build())
                .addTag("task-reminder-${task.id}")
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }

    override fun cancel(taskId: Long) {
        alarmManager.cancel(alarmIntent(taskId))
        WorkManager.getInstance(context).cancelAllWorkByTag("task-reminder-$taskId")
    }

    private fun alarmIntent(taskId: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("taskId", taskId)
        return PendingIntent.getBroadcast(context, taskId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
