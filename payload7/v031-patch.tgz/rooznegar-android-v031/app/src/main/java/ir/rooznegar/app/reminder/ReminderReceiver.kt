package ir.rooznegar.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.rooznegar.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val taskId = intent.getLongExtra("taskId", -1)
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val task = AppDatabase.get(context).taskDao().getById(taskId)
                if (task != null && !task.isCompleted && !task.isCancelled) Notifications.showTask(context, task)
            } finally { pending.finish() }
        }
    }
}
