package ir.rooznegar.app.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import ir.rooznegar.app.data.AppDatabase

class ReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getLong("taskId", -1)
        val task = AppDatabase.get(applicationContext).taskDao().getById(id) ?: return Result.success()
        if (!task.isCompleted && !task.isCancelled) Notifications.showTask(applicationContext, task)
        return Result.success()
    }
}
