package ir.rooznegar.app.reminder

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import ir.rooznegar.app.MainActivity
import ir.rooznegar.app.core.calendar.JalaliCalendar
import ir.rooznegar.app.data.NoteEntity
import ir.rooznegar.app.data.TaskEntity

object Notifications {
    const val REMINDERS = "reminders"
    const val PERSISTENT = "persistent_notes"
    const val DATE_BAR = "date_bar"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannels(listOf(
            NotificationChannel(REMINDERS, "یادآورها", NotificationManager.IMPORTANCE_HIGH),
            NotificationChannel(PERSISTENT, "یادداشت‌های دائمی", NotificationManager.IMPORTANCE_LOW),
            NotificationChannel(DATE_BAR, "تاریخ در نوار اعلان", NotificationManager.IMPORTANCE_MIN)
        ))
    }

    fun showTask(context: Context, task: TaskEntity) {
        if (!canNotify(context)) return
        val open = PendingIntent.getActivity(context, task.id.toInt(), Intent(context, MainActivity::class.java), flags())
        val done = actionIntent(context, task.id, NotificationActionReceiver.ACTION_DONE, 0)
        val snooze10 = actionIntent(context, task.id, NotificationActionReceiver.ACTION_SNOOZE, 10)
        val snooze60 = actionIntent(context, task.id, NotificationActionReceiver.ACTION_SNOOZE, 60)
        val n = NotificationCompat.Builder(context, REMINDERS)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(task.title)
            .setContentText("یادآوری روزنگار")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "انجام شد", done)
            .addAction(0, "۱۰ دقیقه بعد", snooze10)
            .addAction(0, "۱ ساعت بعد", snooze60)
            .build()
        NotificationManagerCompat.from(context).notify(task.id.toInt(), n)
    }

    fun showPinnedNote(context: Context, note: NoteEntity) {
        if (!canNotify(context)) return
        val open = PendingIntent.getActivity(context, (100000 + note.id).toInt(), Intent(context, MainActivity::class.java), flags())
        val n = NotificationCompat.Builder(context, PERSISTENT)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle(note.title.ifBlank { "یادداشت جلوی چشم" })
            .setContentText(note.body)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setStyle(NotificationCompat.BigTextStyle().bigText(note.body))
            .build()
        NotificationManagerCompat.from(context).notify((100000 + note.id).toInt(), n)
    }

    fun cancelPinnedNote(context: Context, noteId: Long) {
        NotificationManagerCompat.from(context).cancel((100000 + noteId).toInt())
    }

    fun showDateBar(context: Context) {
        if (!canNotify(context)) return
        val today = java.time.LocalDate.now()
        val j = JalaliCalendar.fromGregorian(today)
        val title = j.formatLong(JalaliCalendar.dayOfWeekFa(today))
        val n = NotificationCompat.Builder(context, DATE_BAR)
            .setSmallIcon(android.R.drawable.ic_menu_today)
            .setContentTitle(title)
            .setContentText("تقویم فارسی روزنگار")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        NotificationManagerCompat.from(context).notify(42, n)
    }

    fun hideDateBar(context: Context) = NotificationManagerCompat.from(context).cancel(42)

    private fun actionIntent(context: Context, taskId: Long, action: String, minutes: Int): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).setAction(action)
            .putExtra("taskId", taskId).putExtra("minutes", minutes)
        return PendingIntent.getBroadcast(context, (taskId * 10 + minutes).toInt(), intent, flags())
    }

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun canNotify(context: Context): Boolean = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}
