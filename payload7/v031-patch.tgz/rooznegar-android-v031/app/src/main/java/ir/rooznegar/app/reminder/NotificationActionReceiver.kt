package ir.rooznegar.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import ir.rooznegar.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val taskId = intent.getLongExtra("taskId", -1)
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(context).taskDao()
                val task = dao.getById(taskId) ?: return@launch
                when (intent.action) {
                    ACTION_DONE -> {
                        dao.update(task.copy(isCompleted = true, updatedAt = System.currentTimeMillis()))
                        AndroidReminderScheduler(context).cancel(taskId)
                        NotificationManagerCompat.from(context).cancel(taskId.toInt())
                    }
                    ACTION_SNOOZE -> {
                        val minutes = intent.getIntExtra("minutes", 10)
                        val at = System.currentTimeMillis() + minutes * 60_000L
                        val updated = task.copy(reminderEpochMillis = at, updatedAt = System.currentTimeMillis())
                        dao.update(updated)
                        AndroidReminderScheduler(context).schedule(updated)
                        NotificationManagerCompat.from(context).cancel(taskId.toInt())
                    }
                }
            } finally { pending.finish() }
        }
    }

    companion object {
        const val ACTION_DONE = "ir.rooznegar.DONE"
        const val ACTION_SNOOZE = "ir.rooznegar.SNOOZE"
    }
}
