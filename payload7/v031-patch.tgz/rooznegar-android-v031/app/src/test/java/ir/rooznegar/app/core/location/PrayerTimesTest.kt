package ir.rooznegar.app.core.location

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class PrayerTimesTest {
    @Test fun tehranSummerTimes_areChronological() {
        val p = PrayerTimesCalculator.calculate(LocalDate.of(2026, 8, 20), IranianCities.byCode("tehran"))
        val fajr = LocalTime.parse(p.fajr)
        val sunrise = LocalTime.parse(p.sunrise)
        val dhuhr = LocalTime.parse(p.dhuhr)
        val asr = LocalTime.parse(p.asr)
        val maghrib = LocalTime.parse(p.maghrib)
        val isha = LocalTime.parse(p.isha)
        assertTrue(fajr < sunrise)
        assertTrue(sunrise < dhuhr)
        assertTrue(dhuhr < asr)
        assertTrue(asr < maghrib)
        assertTrue(maghrib < isha)
    }

    @Test fun qiblaBearing_isValid() {
        val bearing = PrayerTimesCalculator.qiblaBearing(IranianCities.byCode("tehran"))
        assertTrue(bearing in 0.0..360.0)
    }
}
