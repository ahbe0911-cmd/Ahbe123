package ir.rooznegar.app.core.calendar

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class JalaliCalendarTest {
    @Test fun knownDate_2026_08_20_is_1405_05_29() {
        assertEquals(JalaliDate(1405, 5, 29), JalaliCalendar.fromGregorian(LocalDate.of(2026, 8, 20)))
    }

    @Test fun roundTrip() {
        val dates = listOf(LocalDate.of(2025, 3, 20), LocalDate.of(2026, 8, 20), LocalDate.of(2030, 1, 1))
        dates.forEach { g -> assertEquals(g, JalaliCalendar.toGregorian(JalaliCalendar.fromGregorian(g))) }
    }

    @Test fun monthLength_valid() {
        assertTrue(JalaliCalendar.monthLength(1405, 1) == 31)
        assertTrue(JalaliCalendar.monthLength(1405, 7) == 30)
    }
}
